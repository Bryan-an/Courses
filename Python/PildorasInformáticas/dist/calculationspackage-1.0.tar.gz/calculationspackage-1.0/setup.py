from setuptools import setup

setup(
    name="calculationspackage",
    version="1.0",
    description="Round and pow package",
    author="Bryan",
    author_email="bryanandagoya@gmail.com",
    url="https://github.com/Bryan-an",
    packages=["calculations", "calculations.round_pow"]
)
