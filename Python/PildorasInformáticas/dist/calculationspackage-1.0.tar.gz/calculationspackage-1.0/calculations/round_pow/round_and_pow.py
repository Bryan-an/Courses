def pow(base, exponent):
    print(f"The result of the pow is: {base ** exponent}")


def round_number(number):
    print(f"The result of the round is: {round(number)}")
