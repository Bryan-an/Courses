def sum(op1, op2):
    print(f"The result of the sum is: {op1 + op2}")


def subtract(op1, op2):
    print(f"The result of the subtraction is: {op1 - op2}")


def multiply(op1, op2):
    print(f"The result of the multiplication is: {op1 * op2}")


def divide(dividend, divider):
    print(f"The result of the division is: {dividend / divider}")


def pow(base, exponent):
    print(f"The result of the pow is: {base ** exponent}")


def round_number(number):
    print(f"The result of the round is: {round(number)}")
